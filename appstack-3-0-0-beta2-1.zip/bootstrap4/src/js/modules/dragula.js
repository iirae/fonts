import dragula from "dragula";

window.dragula = dragula;
