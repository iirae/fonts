// Usage: https://github.com/themustafaomar/jsvectormap
import "jsvectormap"
import "jsvectormap/dist/maps/world.js"
import "jsvectormap/dist/maps/us-aea-en.js"